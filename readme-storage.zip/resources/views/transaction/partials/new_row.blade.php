<div id="new_row" style="display: none;">
    <table>
      <tbody>
        <tr>
          <td>
          <select name="product_ids[]" class="form-control"></select>
        </td>
        <td>
          <input type="number" value="" name="product_quantities[]" class="text-right form-control">
        </td>
        <td class="text-center">
          <button class="btn btn-danger" onClick="supplierReturnModule.removeItem($(this));"><i class="fa fa-trash fa-fw"></i></button>
        </td>
      </tr>
    </tbody>
  </table>
</div>