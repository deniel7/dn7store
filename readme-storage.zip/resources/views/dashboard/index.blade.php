@extends('layouts.backend')

@section('title', 'Dashboard')

@section('content')

<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>General Stats</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="{{ url('/home') }}"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Your Page Content Here -->

    </section>
    <!-- /.content -->

@endsection