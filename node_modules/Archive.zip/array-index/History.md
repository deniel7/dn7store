
1.0.0 / 2016-01-02
==================

  * remove `__get__` and `__set__` functionality
  * README: s/->/→/

0.9.1 / 2015-12-29
==================

  * fix backwards compat with tests
  * README: update samples for new Symbols API
  * travis: attempt to fix node v8

0.9.0 / 2015-12-27
==================

  * add backwards compat logic with deprecate message
  * add LICENSE field and entry in package.json
  * convert to using es6 Symbols
  * remove extraneous debug() calls
  * travis: test moar Node.js versions

0.2.0 / 2015-12-02
==================

  * add support for invoking as a Mixin
  * travis: test node v0.6

0.1.1 / 2014-11-03
==================

  * index: use `%o` debug formatters
  * .travis: don't test node v0.9.x
  * README: use svg for Travis badge
  * add .jshintrc file

0.1.0 / 2013-12-01
==================

  * add `History.md` file
  * .travis.yml: test node v0.8-v0.11
  * add component.json
  * package: update "main" field
  * package: beautify

0.0.4 / 2013-09-27
==================

  * ensure that the `length` property has the same maximum as regular Arrays

0.0.3 / 2013-09-15
==================

  * add `toArray()`, `toJSON()`, and `toString()` functions
  * add an `inspect()` function

0.0.2 / 2013-09-15
==================

  * use "configurable: true"
  * add `travis.yml` file

0.0.1 / 2013-06-14
==================

  * Initial release
